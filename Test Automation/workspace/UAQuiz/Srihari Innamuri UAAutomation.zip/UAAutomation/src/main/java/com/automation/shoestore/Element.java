package com.automation.shoestore;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.automation.shoestore.SeHelper;


public class Element {
	
	private int globalSeTimeOut = 20;
	
	private SeHelper se;
	
	 //Return Particular element
   public Element getElement(By name, By css, By xpath, By id) {
		try {
			if (name != null && se.element().getElement(name) != null) {
				return se.element().getElement(name);
			} else if (css != null && se.element().getElement(css) != null) {
				return se.element().getElement(css);
			} else if (xpath != null && se.element().getElement(xpath) != null) {
				return se.element().getElement(xpath);
			} else if (id != null && se.element().getElement(id) != null) {
				return se.element().getElement(id);
			}else {
				 //se.log().logSeStep("No Locator Exists");
				return null;
			}
		} catch (Exception e) {
			return null;
		}
	}
   
   /**
    * Finds and returns the element
    *
    * @param locator
    * @return
    */
   public Element getElement(final By locator) {
       try {
       	se.element().waitForElement(locator);
           return (Element) se.driver().findElement(locator);
       } catch (NoSuchElementException e) {
           return null;
       } catch (Exception e) {
           String errorName = "Un-handled Exception in getElement: " + locator.toString();
           return null;
       }
   }  
   
   public boolean waitForElement(final By locator) {
       return waitForElement(locator, globalSeTimeOut);
   }
   
   public boolean waitForElement(final By locator, int timeOutInSeconds) {
       try {
           new WebDriverWait(se.driver(), timeOutInSeconds)
                   .ignoring(RuntimeException.class)
                   .until(new ExpectedCondition<WebElement>() {
                       public WebElement apply(WebDriver d) {
                           return d.findElement(locator);
                       }
                   });
           return true;
       } catch (TimeoutException e) {
           return false;
       } catch (Exception e) {
           return false;
       }

   }
   
   public List<WebElement> getElements(By nameLocator, By cssLocator, By xpathLocator, By idLocator) 
   {
   	try {
			if (nameLocator != null) {
				return se.element().getElements(nameLocator);
			} else if (cssLocator != null) {
				return se.element().getElements(cssLocator);
			} else if (xpathLocator != null) {
				return se.element().getElements(xpathLocator);
			} else if (idLocator != null) {
				return se.element().getElements(idLocator);
			}else {
				return null;
			}
		} catch (Exception e) {
			return null;
		}
   }
   
   public List<WebElement> getElements(final By locator) {
       try {
           return se.driver().findElements(locator);
       } catch (Exception e) {
           return new ArrayList<WebElement>();
       }
   }


}
