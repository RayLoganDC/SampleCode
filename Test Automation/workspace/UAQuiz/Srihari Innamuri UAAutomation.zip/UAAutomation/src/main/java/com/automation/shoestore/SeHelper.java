package com.automation.shoestore;

import java.util.logging.Level;

import org.openqa.selenium.Proxy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.safari.SafariOptions;

import com.automation.shoestore.Browser.Browsers;
import com.automation.shoestore.Element;
import com.automation.shoestore.Browser;


public class SeHelper {
	
	 private WebDriver driver;
	 private final Element element = new Element();
	 private final Browser browser = new Browser();
	 
	 public Element element() {
	        return element;
	    }
	 
	    public WebDriver driver() {
	        return driver;
	    }
	    
	    public WebDriver buildDriver(Browsers myBrowser, Proxy proxy) {
	        WebDriver driver;
	        DesiredCapabilities capabilities;
	   
	            switch (myBrowser) {
	   
	                case Chrome:
	                	
	                      ChromeOptions chromeOptions;
	                      
	                	 capabilities = DesiredCapabilities.chrome();
	                     chromeOptions = new ChromeOptions();
	                     chromeOptions.addArguments("test-type");  // turn off un-supported flags
	                     capabilities.setCapability(ChromeOptions.CAPABILITY, chromeOptions);
	                	 System.setProperty("webdriver.chrome.driver",getChromedriverPath());
	                     capabilities.setCapability(CapabilityType.PROXY, proxy);
	                     driver= new ChromeDriver(capabilities);
	               
	                    break;

	              
	                case Firefox:
	                    capabilities = DesiredCapabilities.firefox();
	                    capabilities.setCapability(CapabilityType.PROXY, proxy);
	                   // capabilities.setCapability(FirefoxDriver.PROFILE,getFirefoxProfile());
	                    driver = new FirefoxDriver(capabilities);
	                    break;
	                case InternetExplorer:
	                    capabilities = DesiredCapabilities.internetExplorer();
	                    capabilities.setCapability(InternetExplorerDriver.
	                            INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
	                    capabilities.setCapability(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION, true);
	                   //System.setProperty("webdriver.ie.driver", getIEDriverPath());
	                    driver = new InternetExplorerDriver(capabilities);
	                    break;
	                case Safari:
	                    capabilities = DesiredCapabilities.safari();
	                    capabilities.setCapability(CapabilityType.PROXY, proxy);
	                    SafariOptions safariOptions;
	                    safariOptions = new SafariOptions();
	                    safariOptions.setUseCleanSession(true);
	                    capabilities.setCapability(SafariOptions.CAPABILITY, safariOptions);
	                    driver = new SafariDriver(capabilities);
	                    break;  
	                default:
	                    return null;
	                    
	            }
	            
	            return driver;
	    }
	    
	            
	            public String getChromedriverPath() {
	                String chomedriverFilename = "chromedriver.exe"; 
	                return chomedriverFilename;
	            }
	            
	   
	                    
	 

}
