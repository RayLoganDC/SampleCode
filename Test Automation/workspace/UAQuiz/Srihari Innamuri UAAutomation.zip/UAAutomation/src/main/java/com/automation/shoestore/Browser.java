package com.automation.shoestore;

import com.automation.shoestore.SeHelper;

public class Browser {
	
	 private SeHelper se;


	    /**
	     * Supported Browsers
	     */
	    public static enum Browsers {
	        Firefox, Chrome, InternetExplorer, Safari,
	        AppiumIphoneDevice, AppiumIpadDevice, AppiumAndroidDevice,
	    }

}
