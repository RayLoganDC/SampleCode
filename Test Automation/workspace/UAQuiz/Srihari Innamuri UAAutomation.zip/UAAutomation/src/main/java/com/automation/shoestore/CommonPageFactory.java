package com.automation.shoestore;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.automation.shoestore.SeHelper;


public class CommonPageFactory {
	
	public static <T> T initElements(WebDriver driver, java.lang.Class<T> pageClassToProxy) {
		   T obj = PageFactory.initElements(driver, pageClassToProxy);
		   SeHelper se = new SeHelper();
		
		 
		   return obj;
		  }
		  
		  public static <T> T initElements(SeHelper se, java.lang.Class<T> pageClassToProxy) {
			   T obj = PageFactory.initElements(se.driver(), pageClassToProxy);
			 
			   return obj;
			  }

}
