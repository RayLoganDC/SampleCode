package com.automation.shoestore.Test;

import org.openqa.selenium.Proxy;

import com.automation.shoestore.SeHelper;
import com.automation.shoestore.Browser.Browsers;
import com.automation.shoestore.Business.UABusiness;
import com.automation.shoestore.pages.UAHome;

public class UATest {
	
	
	proxy = new Proxy();
	
	
	//We can execute this test method on any browser / mobile device. 
	public void UATest(){
		
		UABusiness UAHome;
		SeHelper se;
		
		Proxy proxy;
		//pass browser as an parameter or argument
		try {
			se.buildDriver(Browsers.Chrome,proxy);
			se.driver().get("https://www.underarmour.com/en-us/");
			
			//we can use this method to click on menu item 
			UAHome.menuitem("Men");
			
			//We can this method to click on any sub menu item
			UAHome.subMenuItem("Short Sleeves");
			
			//we can use this method to click on any product by passing the product value
			UAHome.selectProduct("Men's UA Freedom Shipboard Digi Camo Compression Shirt");
			UAHome.getStyleColor();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
