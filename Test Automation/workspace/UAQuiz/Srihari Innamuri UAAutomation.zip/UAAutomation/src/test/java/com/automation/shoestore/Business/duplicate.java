package com.automation.shoestore.Business;

import java.util.ArrayList;

public class duplicate {
	
	public static void duplicateentry(int[] arr){
		for(int i=0;i<arr.length;i++){
			for(int j=i+1;j<arr.length;j++){
				
				if(arr[i] == arr[j]){
					
					System.out.println("duplicate value is "+arr[i]);
					
				}
				
			}
		}
	}
	
	public static void main(String[] args) {
		
		int[] arr1= {10,11,9,12,8,13,7,1,6,2,5,3,4,1,0};
		int[] arr2= {18,0,17,1,16,2,15,3,14,4,13,5,12,6,11,7,10,8,9,19,3};
		int[] arr3= {6,0,5,1,4,2,3,4};
		
		duplicateentry(arr3);
		
	}

}
