package com.automation.shoestore.Business;

import java.util.List;

import junit.framework.Assert;

import org.openqa.selenium.WebElement;

import com.automation.shoestore.SeHelper;
import com.automation.shoestore.pages.UAHome;

public class UABusiness {
	
	UAHome home = new UAHome();
	
	SeHelper se;
	
	////we can use this method to click on any menu item 
	public void menuitem(String Menuitem){
		
		List<WebElement> items= home.getmenuitems();
		
		for(WebElement item : items){
			
			String actval=item.getText();
			
			if(actval.contains(Menuitem)){
				item.click();
				break;
			}
			
		}
		
	}
	
	////We can this method to click on any sub menu item
	
	public void subMenuItem(String SubMenuitem){
		
		List<WebElement> subitems= home.getSubitems();
		
		for(WebElement subitem : subitems){
			
			String actval=subitem.getText();
			
			if(actval.contains(SubMenuitem)){
				subitem.click();
				break;
			}
			
		}
	}
	
	
	////we can use this method to click on any product by passing the product value
		
		public void selectProduct(String productname){
			
			List<WebElement> products= home.getProduct();
			List<WebElement> title = home.getTitle();
			
			for(int i=0;i<title.size();i++){
				
			  String titleval= title.get(i).getText();
			  
			  if(titleval.equalsIgnoreCase(productname)){
				  products.get(i).click();
				  break;
			  }
				
			}
			
	}
		
		
		public String getStyleColor(){
			
			WebElement style= se.driver().findElement(home.lbl_Style_CSS);
			String Style = style.getText();
			Assert.assertTrue(Style!=null);
			
			return Style;
			
			
	}
		
		
		
}
