package com.automation.shoestore.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;

import com.automation.shoestore.Element;
import com.automation.shoestore.SeHelper;

public class UAHome {
	
	SeHelper se;
	
	
	private By lbl_menu_CSS = By.cssSelector(".item.spotlight-drawer-title>i"); 
	public List<WebElement> getmenuitems() {
		return se.element().getElements(null,lbl_menu_CSS,null,null);
	}
	
	private By lbl_submenu_CSS = By.cssSelector(".item>i"); 
	public List<WebElement> getSubitems() {
		return se.element().getElements(null,lbl_submenu_CSS,null,null);
	}
	
	private By img_Product_CSS = By.cssSelector(".product-img"); 
	public List<WebElement> getProduct() {
		return se.element().getElements(null,img_Product_CSS,null,null);
	}
	

	private By lbl_title_CSS = By.cssSelector(".title>a"); 
	public List<WebElement> getTitle() {
		return se.element().getElements(null,lbl_title_CSS,null,null);
	}
	
	public By lbl_Style_CSS = By.cssSelector(".buypanel_productstyle-num"); 
	
}
